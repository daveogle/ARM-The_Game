/*
 * Event Class
 */

function Event(hardEvent, description, targetTime)
{
    this.targetTime = targetTime;
    this.hardEvent = hardEvent;
    this.description = description;
}

Event.prototype = {
    getTargetTime: function ()
    {
        return this.targetTime;
    },
    setTargetTime: function (time)
    {
        this.targetTime = time;
    },
    getHardEvent: function ()
    {
        return this.hardEvent;
    },
    setHardEvent: function (hardEvent)
    {
        this.hardEvent = hardEvent;
    },
    getDescription: function ()
    {
        return this.description;
    },
    setDescription: function (description)
    {
        this.description = description;
    }
};
//EOF