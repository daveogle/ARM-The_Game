/* 
 * Game Controller class
 */
var model;
var gameView;
var gameOver = false;
var waveTimer; 
var interval;
var counter;
var eventId = 1;

function startNewGame(canvas, stage, queue, mute)
{
    this.gameOver = false;
    this.gameView = new GameView(canvas, stage, queue, mute);
    this.model = new GameModel();
    this.model.newGame();
    this.gameView.buildBackground();
    this.gameView.setTankerPool();
    this.gameView.drawDriverPool();
    this.gameView.displayLevel(1);
    this.interval = this.model.getWaveTimings();
    this.counter = 0;
    this.waveTimer = new Worker("Scripts/Game/WaveCountDownTimerWebWorker.js");
    startWaveTimer(2000);
}

function startNextWaveTimer()
{
    //if all tasks have been dropped this wave
    //console.log("Counter = " + this.counter + " Interval Length = " + this.interval.length);
    //check end of game
    var endGameScore = this.model.checkEndGame();
    if (endGameScore !== -1)
    {
        this.gameView.endGame(endGameScore);
    }
    else
    {
        if (this.counter === this.interval.length - 1)
        {
            var level = this.model.levelUp();
            this.interval = this.model.getWaveTimings();
            this.counter = 0;
            this.gameView.displayLevel(level);
        }
        startWaveTimer(interval[counter]);//set next timer up
        //console.log(interval[counter]);
    }
}

function startWaveTimer(time)
{
    //interval = an array holding the timings for dropping tasks for this wave.
    this.waveTimer.postMessage(time);//2 1/2 seconds for first task to drop 
    this.waveTimer.onmessage = function (event) {
        if (!gameOver)
        {
            var task = model.dropNewTask();
            if (task.getFuelRequired === 0)//GAME OVER MAN, GAME OVER!
            {
                gameOver = true;
                this.gameView.animateAircraftLand(task);
                waveTimer.terminate();
            }
            else //drop a task
            {
                gameView.animateAircraftLand(task);
            }
        }
        else
        {
            waveTimer.terminate();
        }
    };
    this.counter = this.counter + 1;//tick off an interval
}

function updateTankers()
{
    var tankerFuel = this.model.getTankerFuel();
    return tankerFuel;
}

function getNewDrivers()
{
    var driverPool = this.model.getAllDrivers();
    return driverPool;
}

function taskCardClickedEventHandler(slot)
{
    var taskValid = this.model.validateTaskNumber(slot); //convert the slot to a task number and check not selected
    if (taskValid)//task not already selected or busy
    {
        var fuel = this.model.taskClicked(slot);
        this.gameView.setTaskSelected(slot);
        if (fuel !== null)//if the fuel values for a started task have been set
        {
            startJob(fuel);
        }
    }
}

function tankerClickedEventHandler(tanker)
{
    if (!(this.model.getTanker(tanker).getBusy()) && !(this.model.getTanker(tanker).getSelected()))
    {
        var fuel = this.model.tankerClicked(tanker);
        this.gameView.setTankerSelected(tanker);
        if (fuel !== null)
        {
            startJob(fuel);
        }
    }
}

function driverClickedEventHandler(driver)
{
    if (!(this.model.getDriver(driver).getBusy()) && !(this.model.getDriver(driver).getSelected()))
    {
        var fuel = this.model.driverClicked(driver);
        this.gameView.setDriverSelected(driver);
        if (fuel !== null)
        {
            startJob(fuel);
        }
    }
}

function driverDoubleClickedEventHandler(driver)
{
    return model.getDriverDescription(driver);
}

function startJob(fuel) //fuel = {truck fuel, task fuel}
{
    var jobDetails = this.model.getLatestJobDetails();//jobDetails = {task, tanker, driver} numbers
    if (fuel[0] === 0)
    {
        this.gameView.showTankerMessage("Time to bulk!", "This Tanker is empty and can't be used for refueling until it has been sent to Bulk");
        this.model.setTaskBusy(jobDetails[0], false);
        this.model.getTanker(jobDetails[1]).setBusy(false);
        this.model.getDriver(jobDetails[2]).setBusy(false);
        this.gameView.toggleJobUnselectable(false, jobDetails[0], jobDetails[1], jobDetails[2]);
        this.model.endJob(jobDetails[0], fuel[1], 0);
    }
    else
    {
        this.model.setTaskBusy(jobDetails[0], true);
        this.model.getTanker(jobDetails[1]).setBusy(true);
        this.model.getDriver(jobDetails[2]).setBusy(true);
        this.gameView.toggleJobUnselectable(true, jobDetails[0], jobDetails[1], jobDetails[2]);
        this.gameView.animateTruckStart(fuel, jobDetails);
    }
}

function updateJobView(fuel, jobDetails)
{
    var taskEventTime = this.model.getEvent(jobDetails[0]).getTargetTime();
    var eventDescription = this.model.getEvent(jobDetails[0]).getDescription();
    var fuelNeeded = fuel[1];
    var jobTimer = new Worker("Scripts/Game/CountDownTimerWebWorker.js");
    jobTimer.postMessage((fuel[1] * 10) + 500);
    jobTimer.onmessage = function (event) {
        if (!gameOver)
        {
            fuel[1] = fuel[1] - 10;
            fuel[0] = fuel[0] - 10;
            if (fuel[1] < 10)//Round off
            {
                fuel[1] = 0;
            }
            if (fuel[0] < 10)
            {
                fuel[0] = 0;
            }
            //UPDATE THE JOB VIEW 
            gameView.refuelJet(jobDetails[1], fuel[0], jobDetails[0], fuel[1]);
            if (fuel[0] === 0 || fuel[1] === 0)//Job Complete
            {
                jobTimer.terminate();
                gameView.animateTankerLeaving(jobDetails, fuel[0], fuel[1], false);
            }
            if (fuel[1] < taskEventTime && fuelNeeded >= taskEventTime)//if event has happened
            {
                jobTimer.terminate();
                gameView.animateTankerLeaving(jobDetails, fuel[0], fuel[1], true);
                gameView.showEventMessage("Oh no!", eventDescription, eventId);
                eventId++;
            }
        }
    };
}

function refuelComplete(jobDetails, tankerFuel, taskFuelLeft)//also handles empty tanker
{
    this.model.setTaskBusy(jobDetails[0], false);
    this.model.getTanker(jobDetails[1]).setBusy(false);
    this.model.getDriver(jobDetails[2]).setBusy(false);
    this.gameView.toggleJobUnselectable(false, jobDetails[0], jobDetails[1], jobDetails[2]);
    if (taskFuelLeft === 0)
    {
        this.gameView.animateAircraftLeaving(jobDetails[0]);
        var score = this.model.endJob(jobDetails[0], taskFuelLeft);
        this.gameView.removeTask(jobDetails[0]);
        updateDrivers();
        this.gameView.updateScore(score);
    }
    else
    {
        this.model.endJob(jobDetails[0], taskFuelLeft);
    }
    this.model.getTanker(jobDetails[1]).setFuelLevel(tankerFuel);
}

function randomEvent(jobDetails, tankerFuel, taskFuelLeft)
{
    this.model.setTaskBusy(jobDetails[0], false);
    this.model.getTanker(jobDetails[1]).setBusy(false);
    this.model.getDriver(jobDetails[2]).setBusy(false);
    this.gameView.toggleJobUnselectable(false, jobDetails[0], jobDetails[1], jobDetails[2]);
    var event = this.model.getEvent(jobDetails[0]);
    this.model.endJob(jobDetails[0], taskFuelLeft);
    if (event.getHardEvent())
    {
        tankerFuel = 0;
        this.gameView.refuelJet(jobDetails[1], tankerFuel, jobDetails[0], taskFuelLeft);
    }
    this.model.getTanker(jobDetails[1]).setFuelLevel(tankerFuel);
}

function bulkClickedEventHander(tanker)
{
    var bulkTimer = null;
    if (!(this.model.getTanker(tanker).getBusy()))
    {
        var fuel = this.model.getTanker(tanker).getFuelLevel();
        var needed = this.model.getTanker(tanker).getMaxLevel();
        if (this.gameView.bulkTanker(tanker, fuel, needed))
        {
            this.model.sendToBulk(tanker);
            bulkTimer = new Worker("Scripts/Game/CountDownTimerWebWorker.js");
            bulkTimer.postMessage(((needed - fuel) + 500) * 10);
            bulkTimer.onmessage = function (event) {
                fuel = (fuel + 10);
                if (fuel >= needed)
                {
                    gameView.updateTankerFuel(tanker, fuel, "#000000");
                    bulkTimer.terminate();
                    model.bulkTanker(tanker);
                    gameView.toggleTankerUnselectable(tanker, false);
                }
                else
                {
                    gameView.updateTankerFuel(tanker, fuel, "#003D00");
                }
            };
        }
    }
}

function levelUpClickedEventHandler(driver)
{
    var score = this.model.levelUpDriver(driver);
    updateDrivers();
    this.gameView.updateScore(score);
}

//update all drivers
function updateDrivers()
{
    for (var driverNum = 1; driverNum < 5; driverNum++)
    {
        var driver = this.model.checkLevelUp(driverNum);
        this.gameView.updateDriverCard(driverNum, driver.getCurrentLevel(), driver.getNextLevelCost(), driver.getCanLevelUp());
    }
}

function quit(mute)
{
    this.waveTimer.terminate();
    this.gameOver = true;
    delete this.gameView;
    restart(!mute);
}
//EOF
