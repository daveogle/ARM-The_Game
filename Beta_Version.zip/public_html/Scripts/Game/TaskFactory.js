/* 
 * TaskFactory Class
 */

function TaskFactory()
{
    this.aircaftSlots = [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false];
    this.aircraft = ["aircraft1", "aircraft2", "aircraft3", "aircraft4"];
}
;

TaskFactory.prototype = {
    constructor: TaskFactory,
    fuelNeededGenerator: function ()
    {
        //random fuel ammount between 200 and 10,000;
        var fuel;
        fuel = Math.floor((Math.random() * 1800/*9800*/) + 1);
        fuel = fuel + 200;
        return fuel;
    },
    slotGenerator: function ()
    {
        var slot;
        do {
            slot = Math.floor((Math.random() * 16) + 1);
        } while (this.aircaftSlots[slot - 1]);
        this.aircaftSlots[slot - 1] = true;
        return slot;
    },
    createTask: function ()
    {
        var slot = this.slotGenerator();
        var aircraft = this.aircraft[Math.floor(Math.random() * 4)];
        var fuel = this.fuelNeededGenerator();
        var task = new Task(slot, fuel, aircraft);
        return task;
    },
    isInUse: function (slot, inUse)
    {
        if (!inUse)
        {
            this.aircaftSlots[slot - 1] = false;
        }
        else
        {
            this.aircaftSlots[slot - 1] = true;
        }
    }
};
//EOF
