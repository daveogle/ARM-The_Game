var canvas;
var stage;
var queue;
function StartView()
{
    this.aircraftSpritesheet;
    this.tankerSpritesheet;
    this.mute = true;
    this.scrolling = false;
    this.mainTheme;
}

StartView.prototype = {
    constructor: StartView,
    init: function ()
    {
        queue = new createjs.LoadQueue();
        createjs.Sound.alternateExtensions = ["wav"];
        queue.installPlugin(createjs.Sound);
        queue.addEventListener('complete', this.loadComplete.bind(this));
        queue.loadManifest([
            {id: "background", src: "Assets/background.png"},
            {id: "tankerMedium", src: "Assets/truckMedium.jpg"},
            {id: "tankerSmall", src: "Assets/truckSmall.png"},
            {id: "tankerMediumS", src: "Assets/truckMediumS.png"},
            {id: "tankerSmallS", src: "Assets/truckSmallS.png"},
            {id: "tankerMediumU", src: "Assets/truckMediumU.png"},
            {id: "tankerSmallU", src: "Assets/truckSmallU.png"},
            {id: "bulkButton", src: "Assets/bulkButton.png"},
            {id: "bulkButtonS", src: "Assets/bulkButtonS.png"},
            {id: "driverCard", src: "Assets/driverCard.png"},
            {id: "driverCardS", src: "Assets/driverCardS.png"},
            {id: "driverCardU", src: "Assets/driverCardU.png"},
            {id: "taskCard", src: "Assets/taskCard.png"},
            {id: "taskCardS", src: "Assets/taskCardS.png"},
            {id: "taskCardU", src: "Assets/taskCardU.png"},
            {id: "avatar1", src: "Assets/avatar1.gif"},
            {id: "avatar2", src: "Assets/avatar2.gif"},
            {id: "avatar3", src: "Assets/avatar3.gif"},
            {id: "avatar4", src: "Assets/avatar4.gif"},
            {id: "avatar5", src: "Assets/avatar5.gif"},
            {id: "avatar6", src: "Assets/avatar6.gif"},
            {id: "levelUpButtonU", src: "Assets/levelUpU.png"},
            {id: "levelUpButton", src: "Assets/levelUp.png"},
            {id: "aircraft", src: "Assets/aircraftSprites.png"},
            {id: "tankers", src: "Assets/tankerSprites.png"},
            {id: "startButton", src: "Assets/startButton.png"},
            {id: "helpButton", src: "Assets/help.png"},
            {id: "mute", src: "Assets/mute.png"},
            {id: "unmute", src: "Assets/unmute.png"},
            //sound files
            {id: "flyby", src: "Assets/Sounds/flyby.wav"},
            {id: "taxi", src: "Assets/Sounds/taxi.wav"},
            {id: "truckMove", src: "Assets/Sounds/truckMove.wav"},
            {id: "taskComplete", src: "Assets/Sounds/taskComplete.wav"},
            {id: "eventSound", src: "Assets/Sounds/event.wav"},
            {id: "levelUp", src: "Assets/Sounds/levelUp.wav"},
            {id: "land", src: "Assets/Sounds/airland.wav"},
            {id: "themeTune", src: "Assets/Sounds/themeTune.wav"}
        ]);
    },
    setupStage: function ()
    {
        this.canvas = document.getElementById('myGame');
        stage = new createjs.Stage(this.canvas);
        createjs.Ticker.setFPS(60);
        createjs.Ticker.addEventListener("tick", function (e) {
            stage.update();
        });
    },
    drawSprites: function ()
    {
        var aircraftData = {
            "images": [queue.getResult("aircraft")],
            "frames": [[0, 0, 100, 80], [0, 90, 100, 80], [0, 180, 100, 80], [0, 270, 100, 80]],
            "animations": {"aircraft1": [0],
                "aircraft2": [1],
                "aircraft3": [2],
                "aircraft4": [3]}
        };
        var tankerData = {
            "images": [queue.getResult("tankers")],
            "frames": [[0, 0, 100, 40], [0, 50, 100, 80], [0, 140, 100, 40]],
            "animations": {"smallTanker": [0],
                "mediumTanker": [2],
                "largeTanker": [1]
            }
        };
        this.aircraftSpritesheet = new createjs.SpriteSheet(aircraftData);
        this.tankerSpritesheet = new createjs.SpriteSheet(tankerData);
    },
    loadComplete: function ()
    {
        this.setupStage();
        displayStartScreen("Welcome to Aircraft Refueller Manager - the game", true);
    },
    drawBackground: function ()
    {
        this.canvas.style.borderStyle = "none";
    },
    drawStartButton: function ()
    {
        var startButton = new createjs.Bitmap(queue.getResult("startButton"));
        var helpButton = new createjs.Bitmap(queue.getResult("helpButton"));
        //var aboutButton = new createjs.Bitmap(queue.getResult("helpButton"));
        startButton.x = 270;
        startButton.y = 410;
        helpButton.x = 650;
        helpButton.y = 410;
        startButton.addEventListener('click', function startClick(e) {
            var loadedImages = [this.queue, this.aircraftSpritesheet, this.tankerSpritesheet];
            this.mainTheme.stop();
            startButtonClicked(this.canvas, this.stage, loadedImages, this.mute);
        }.bind(this));
        helpButton.addEventListener('click', function helpClick(e) {
            helpButtonClicked();
        });
        stage.addChild(startButton, helpButton);
    },
    drawMuteButton: function ()
    {
        var button;
        if (this.mute)
        {
            createjs.Sound.setMute(false);
            button = new createjs.Bitmap(queue.getResult("mute"));
            this.mute = false;
        }
        else
        {
            createjs.Sound.setMute(true);
            this.mute = true;
            button = new createjs.Bitmap(queue.getResult("unmute"));
        }
        button.x = 900;
        button.y = 25;
        button.addEventListener('click', function startClick(e) {
            muteButtonClickedEventHandler();
        }.bind(this));
        stage.addChild(button);
    },
    drawMessage: function (message)
    {
        stage.removeAllChildren();
        var roundedRectangle = new createjs.Shape();
        roundedRectangle.graphics.beginStroke('#000');
        roundedRectangle.graphics.beginFill('#4E78A8');
        roundedRectangle.graphics.drawRoundRect(50, -50, 800, 500, 20);
        roundedRectangle.x = 150;
        roundedRectangle.y = 51;
        stage.addChild(roundedRectangle);
        var mainMessage = new createjs.Text(message, "5em Lora", "#880015");
        //mainMessage.y = 150;
        mainMessage.x = 600;
        mainMessage.lineWidth = stage.canvas.width - 500;
        mainMessage.lineHeight = 75;
        mainMessage.textAlign = "center";
        stage.addChild(mainMessage);
        var aircraftImage1 = "aircraft1";
        var aircraftImage2 = "aircraft2";
        var aircraftImage3 = "aircraft3";
        var aircraftImage4 = "aircraft4";
        var aircraft1 = new createjs.Sprite(this.aircraftSpritesheet, aircraftImage1);
        var aircraft2 = new createjs.Sprite(this.aircraftSpritesheet, aircraftImage2);
        var aircraft3 = new createjs.Sprite(this.aircraftSpritesheet, aircraftImage3);
        var aircraft4 = new createjs.Sprite(this.aircraftSpritesheet, aircraftImage4);
        aircraft1.x = -100;
        aircraft2.x = -200;
        aircraft3.x = -300;
        aircraft4.x = -400;
        aircraft1.y = 320;
        aircraft2.y = 320;
        aircraft3.y = 320;
        aircraft4.y = 320;
        stage.addChild(aircraft1, aircraft2, aircraft3, aircraft4);
        createjs.Tween.get(aircraft1).to({x: 1200}, 3000);
        createjs.Tween.get(aircraft2).to({x: 1200}, 3500);
        createjs.Tween.get(aircraft3).to({x: 1200}, 4000);
        createjs.Tween.get(aircraft4).to({x: 1200}, 4500).call(function endFlyBy() {
            getScrollMessage();
        });
        createjs.Sound.play("flyby");
        this.mainTheme = createjs.Sound.play("themeTune", createjs.Sound.INTERUPT_NONE, 1000, 0, 10);
    },
    scrollMessage: function ()
    {
        if (!this.scrolling)
        {
            this.scrolling = true;
            console.log("scrolling");
            var scrolltext = "A Game by Dave Ogle©                         Press 'Start Game' to begin.";
            var scrollMessagetxt = new createjs.Text(scrolltext, "60px Indie Flower", "#880015");
            scrollMessagetxt.x = 1400;
            scrollMessagetxt.y = 550;
            var aircraft = "aircraft1";
            var aircraftImage = new createjs.Sprite(this.aircraftSpritesheet, aircraft);
            aircraftImage.x = 1300;
            aircraftImage.y = 550;
            aircraftImage.scaleX = -1;
            stage.addChild(aircraftImage, scrollMessagetxt);
            createjs.Tween.get(aircraftImage).to({x: -750}, 17600);
            createjs.Tween.get(scrollMessagetxt).to({x: -2000}, 30000).call(function endScroll() {
                this.scrolling = false;
                console.log("stopped scrolling");
                getScrollMessage();
            }.bind(this));
        }
    },
    showHelpMessage: function ()
    {
        var desDOM = new createjs.DOMElement(helpMessageBox);
        desDOM.alpha = 0;
        desDOM.regX = 200;
        desDOM.x = stage.canvas.width / 2;
        stage.addChild(desDOM);
        document.getElementById('helpMessageBox').style.display = 'block';
        createjs.Tween.get(desDOM).wait(100).to({y: 20, alpha: 1}, 1000,
                createjs.Ease.quadOut);
        $('#helpMessageBox').css('zIndex', 600);
    },
    setMute: function (mute)
    {
        this.mute = mute;
    }
};
//EOF
